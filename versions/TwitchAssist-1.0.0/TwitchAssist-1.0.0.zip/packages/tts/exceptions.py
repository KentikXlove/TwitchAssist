class TTSException(Exception):
    pass
class DatabaseError(Exception):
    pass
import os
import sys
import json
import requests
import ctypes
import zipfile
from win32com.client import Dispatch
import re

# ========== КОНФИГУРАЦИЯ ==========
INSTALL_DIR = "C:\\TwitchAssist"
APP_NAME = "TwitchAssist"
JSON_URL = "https://raw.githubusercontent.com/KentikXlove/TwitchAssist/main/system.json"
VERSION_FILE = "version.txt"

# ========== ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ ==========
def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False

def print_banner():
    print("Установщик TwitchAssist")
    print()

def is_valid_exe(filepath):
    try:
        with open(filepath, "rb") as f:
            return f.read(2) == b"MZ"
    except:
        return False

def download_file_from_google_drive(file_id, destination):
    """
    Скачивание файла с Google Drive (рабочий метод)
    """
    url = "https://drive.google.com/uc"
    params = {'id': file_id, 'export': 'download'}
    session = requests.Session()
    session.headers.update({"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"})

    try:
        response = session.get(url, params=params, timeout=30)
        response.raise_for_status()
    except Exception as e:
        print(f"Ошибка соединения: {e}")
        return False

    if 'uc-download-link' in response.text or 'confirm' in response.text:
        form_data = {}
        hidden_fields = re.findall(r'<input type="hidden" name="([^"]+)" value="([^"]+)"', response.text)
        for name, value in hidden_fields:
            form_data[name] = value

        action_match = re.search(r'<form[^>]+action="([^"]+)"', response.text)
        action_url = action_match.group(1) if action_match else "https://drive.usercontent.google.com/download"

        for key, value in params.items():
            if key not in form_data:
                form_data[key] = value

        try:
            download_response = session.get(action_url, params=form_data, stream=True, timeout=30)
        except Exception as e:
            print(f"Ошибка загрузки: {e}")
            return False

        if download_response.history:
            final_response = download_response.history[-1]
            if final_response.status_code == 302:
                redirect_url = final_response.headers.get('Location')
                if redirect_url:
                    try:
                        download_response = session.get(redirect_url, stream=True, timeout=30)
                    except Exception as e:
                        print(f"Ошибка перенаправления: {e}")
                        return False

        if download_response.status_code != 200:
            print(f"Ошибка HTTP {download_response.status_code}")
            return False

        total_size = int(download_response.headers.get('content-length', 0))
        try:
            with open(destination, 'wb') as f:
                downloaded = 0
                for chunk in download_response.iter_content(chunk_size=32768):
                    if chunk:
                        f.write(chunk)
                        downloaded += len(chunk)
                        if total_size > 0:
                            percent = (downloaded / total_size) * 100
                            sys.stdout.write(f"\rЗагрузка: {percent:.1f}%")
                            sys.stdout.flush()
            print()
        except Exception as e:
            print(f"Ошибка записи: {e}")
            return False

        return True
    else:
        print("Страница не содержит форму подтверждения")
        return False

def fetch_versions():
    try:
        response = requests.get(JSON_URL, timeout=10)
        response.raise_for_status()
        data = response.json()
        if not isinstance(data, list):
            print("system.json должен содержать список версий")
            return None
        return data
    except Exception as e:
        print(f"Не удалось загрузить system.json: {e}")
        return None

def get_installed_version():
    version_path = os.path.join(INSTALL_DIR, VERSION_FILE)
    if os.path.exists(version_path):
        with open(version_path, "r", encoding="utf-8") as f:
            return f.read().strip()
    return None

def save_version(version):
    version_path = os.path.join(INSTALL_DIR, VERSION_FILE)
    os.makedirs(INSTALL_DIR, exist_ok=True)
    with open(version_path, "w", encoding="utf-8") as f:
        f.write(version)

def create_shortcut(target_path, shortcut_path, working_dir):
    try:
        shell = Dispatch("WScript.Shell")
        shortcut = shell.CreateShortCut(shortcut_path)
        shortcut.TargetPath = target_path
        shortcut.WorkingDirectory = working_dir
        shortcut.WindowStyle = 1
        shortcut.Save()
        return True
    except Exception as e:
        print(f"Ошибка ярлыка: {e}")
        return False

def find_exe_in_directory(directory):
    for root, dirs, files in os.walk(directory):
        for file in files:
            if file.lower().endswith('.exe'):
                return os.path.join(root, file)
    return None

def install_version(version_data):
    version = version_data["version"]
    files = version_data.get("files", [])
    if not files:
        print(f"В версии {version} нет файлов для скачивания")
        return False

    os.makedirs(INSTALL_DIR, exist_ok=True)
    print(f"Установка версии {version}...")

    for file_info in files:
        file_name = file_info["name"]  # например, "launcher.exe", но это ZIP
        file_id = file_info["id"]
        zip_path = os.path.join(INSTALL_DIR, f"{file_name}.zip") if not file_name.endswith('.zip') else os.path.join(INSTALL_DIR, file_name)

        # Проверяем, есть ли уже исполняемый файл
        exe_path = find_exe_in_directory(INSTALL_DIR)
        if exe_path and is_valid_exe(exe_path):
            print("Исполняемый файл уже существует, пропускаем скачивание")
            continue

        print(f"Скачивание {file_name} (архив)...")
        if not download_file_from_google_drive(file_id, zip_path):
            print(f"Ошибка скачивания {file_name}")
            return False

        print("Распаковка архива...")
        try:
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                zip_ref.extractall(INSTALL_DIR)
            print("Архив распакован")
            os.remove(zip_path)
            print("ZIP-архив удалён")
        except Exception as e:
            print(f"Ошибка распаковки: {e}")
            return False

    # Поиск EXE после распаковки
    exe_path = find_exe_in_directory(INSTALL_DIR)
    if not exe_path:
        print(f"Исполняемый файл не найден в {INSTALL_DIR}")
        return False

    print(f"Найден исполняемый файл: {exe_path}")

    # Создание ярлыков
    desktop = os.path.join(os.environ["USERPROFILE"], "Desktop")
    start_menu = os.path.join(os.environ["APPDATA"], "Microsoft", "Windows", "Start Menu", "Programs")

    desktop_shortcut = os.path.join(desktop, f"{APP_NAME}.lnk")
    if create_shortcut(exe_path, desktop_shortcut, INSTALL_DIR):
        print("Ярлык на рабочем столе создан")

    start_shortcut = os.path.join(start_menu, f"{APP_NAME}.lnk")
    if create_shortcut(exe_path, start_shortcut, INSTALL_DIR):
        print("Ярлык в меню Пуск создан")

    save_version(version)
    print(f"Версия {version} успешно установлена")
    return True

# ========== ГЛАВНАЯ ФУНКЦИЯ ==========
def main():
    if not is_admin():
        print("Предупреждение: программа не запущена от имени администратора!")
        print("Некоторые операции (запись в C:\\) могут не работать.")
        print()

    print_banner()

    versions = fetch_versions()
    if not versions:
        input("Нажмите Enter для выхода...")
        sys.exit(1)

    print("Доступные версии:")
    for idx, v in enumerate(versions, start=1):
        ver = v["version"]
        latest = " (latest)" if v.get("latest", False) else ""
        print(f"  {idx}. {ver}{latest}")
    print()

    installed = get_installed_version()
    if installed:
        print(f"Установлена версия: {installed}")

    default_choice = None
    for idx, v in enumerate(versions, start=1):
        if v.get("latest", False):
            default_choice = idx
            break
    if default_choice is None and versions:
        default_choice = 1

    if installed and installed == versions[default_choice-1]["version"]:
        print("У вас уже установлена последняя версия.")
        input("Нажмите Enter для выхода...")
        return

    if installed:
        print(f"Доступно обновление до {versions[default_choice-1]['version']}")
        choice = input("Установить/обновить? (y/N): ").strip().lower()
        if choice != "y":
            print("Отменено.")
            input("Нажмите Enter для выхода...")
            return
        selected_version = versions[default_choice-1]
    else:
        print("Программа не установлена.")
        choice = input(f"Выберите номер версии (по умолчанию {default_choice}): ").strip()
        if choice == "":
            selected_version = versions[default_choice-1]
        else:
            try:
                idx = int(choice) - 1
                if 0 <= idx < len(versions):
                    selected_version = versions[idx]
                else:
                    print(f"Неверный номер, выбрана версия по умолчанию")
                    selected_version = versions[default_choice-1]
            except ValueError:
                print(f"Неверный ввод, выбрана версия по умолчанию")
                selected_version = versions[default_choice-1]

    success = install_version(selected_version)
    if success:
        print()
        print("=" * 50)
        print("    Установка/обновление завершено!")
        print("=" * 50)
        print(f"Папка установки: {INSTALL_DIR}")
        print(f"Ярлык на рабочем столе: {APP_NAME}")
        print(f"Ярлык в меню Пуск: {APP_NAME}")
    else:
        print("Установка не удалась. Проверьте подключение к интернету и доступность файлов.")

    input("Нажмите Enter для выхода...")

if __name__ == "__main__":
    main()
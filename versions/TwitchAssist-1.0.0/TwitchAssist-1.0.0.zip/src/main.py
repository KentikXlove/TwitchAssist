import sys
import os
import threading
import json
import urllib.request   # для скачивания

sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'packages'))

from app import create_app
from packages.web_window.window import run_window

# ========== ИЗМЕНЕНИЕ: функция для получения корневой папки приложения ==========
def get_app_dir() -> str:
    """
    Возвращает директорию, в которой находится исполняемый файл (если приложение
    собрано PyInstaller) или корень проекта (при разработке).
    """
    if getattr(sys, 'frozen', False):
        # Запущено как .exe
        return os.path.dirname(sys.executable)
    else:
        # Разработка: корень проекта — два уровня выше, если этот файл лежит в src/
        return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def main():
    # ИЗМЕНЕНИЕ: корневая папка определяется через get_app_dir()
    app_dir = get_app_dir()

    # ---------------------- Проверка критических файлов ----------------------
    critical_files = [
        {
            'path': 'emotes.json',
            'url': 'https://raw.githubusercontent.com/KentikXlove/TwitchAssist/main/emotes.json'
        }
        # При необходимости можно добавить другие файлы
    ]

    def download_file(url, dest_path):
        """Скачивает файл по URL и сохраняет по указанному пути."""
        try:
            print(f"Скачивание {dest_path} из {url} ...")
            urllib.request.urlretrieve(url, dest_path)
            print("Загрузка завершена.")
            return True
        except Exception as e:
            print(f"Ошибка при скачивании: {e}")
            return False

    for file_info in critical_files:
        # ИЗМЕНЕНИЕ: файлы ищем в app_dir
        file_path = os.path.join(app_dir, file_info['path'])
        if not os.path.exists(file_path):
            print(f"Критический файл {file_path} не найден. Начинаем загрузку...")
            success = download_file(file_info['url'], file_path)
            if not success or not os.path.exists(file_path):
                print(f"Не удалось загрузить {file_info['path']}. Программа не может продолжить работу.")
                sys.exit(1)
            print(f"Файл {file_info['path']} успешно загружен.")
        else:
            print(f"Файл {file_path} уже существует.")

    # ---------------------- Конец блока проверки ----------------------------

    # ИЗМЕНЕНИЕ: создаём приложение и передаём ему app_dir
    app, socketio = create_app(app_dir)

    # Путь к иконке — тоже в app_dir
    icon_path = os.path.join(app_dir, 'icon.ico')

    # Чтение начального значения always_on_top из config.json (теперь рядом с exe)
    config_path = os.path.join(app_dir, 'config.json')
    always_on_top = False
    if os.path.exists(config_path):
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                config = json.load(f)
                always_on_top = config.get('overlay', {}).get('always_on_top', False)
        except Exception:
            pass

    def run_flask():
        socketio.run(app, host='127.0.0.1', port=5001, debug=False, use_reloader=False, allow_unsafe_werkzeug=True)

    flask_thread = threading.Thread(target=run_flask, daemon=True)
    flask_thread.start()

    run_window('http://127.0.0.1:5001',
               title='TwitchAssist',
               width=1200,
               height=800,
               icon_path=icon_path,
               always_on_top=always_on_top)


if __name__ == '__main__':
    main()
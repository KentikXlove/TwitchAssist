import sys
from PyQt5.QtWidgets import QApplication, QMainWindow
from PyQt5.QtCore import Qt

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        # Устанавливаем флаг "поверх всех окон"
        self.setWindowFlags(Qt.WindowStaysOnTopHint)
        self.setWindowTitle("Всегда сверху")
        self.setGeometry(100, 100, 300, 200)
        self.show()

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = MainWindow()
    sys.exit(app.exec_())
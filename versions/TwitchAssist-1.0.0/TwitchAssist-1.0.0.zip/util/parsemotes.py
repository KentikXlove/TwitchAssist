import sys
import json
from bs4 import BeautifulSoup

def extract_emotes_from_html_file(file_path):
    with open(file_path, 'r', encoding='utf-8') as f:
        html = f.read()
    soup = BeautifulSoup(html, 'html.parser')
    emotes = {}  # словарь: name -> link

    for span in soup.find_all('span', attrs={'data-a-target': 'emote-name'}):
        img = span.find('img')
        if img:
            name = img.get('alt', '').strip()
            url = img.get('src', '').strip()
            if name and url and name not in emotes:
                # Если ссылка начинается с //, добавим https:
                if url.startswith('//'):
                    url = 'https:' + url
                emotes[name] = url

    return emotes

def main():
    file_name = sys.argv[1] if len(sys.argv) > 1 else 'chat.html'
    try:
        emotes_dict = extract_emotes_from_html_file(file_name)
    except FileNotFoundError:
        print(f"Ошибка: файл '{file_name}' не найден.", file=sys.stderr)
        sys.exit(1)

    # Проверим, не содержат ли ссылки локальные пути
    for name, link in emotes_dict.items():
        if link.startswith('./') or link.startswith('../') or not link.startswith('http'):
            print(f"Предупреждение: ссылка для '{name}' выглядит как локальный путь: {link}", file=sys.stderr)

    # Сохраняем как объект JSON
    with open('../src/emotes.json', 'w', encoding='utf-8') as f:
        json.dump(emotes_dict, f, indent=2, ensure_ascii=False)

    print(f"✅ Сохранено {len(emotes_dict)} уникальных эмоций в emotes.json")

if __name__ == '__main__':
    main()